cài đặt pip3 install python-whois
cài đặt sublist3r trene kali
pip install dnspython
pip install nmap
nmap -A -vV -p- domain

# marketplace install all
# modules search <keyword>
# modules load recon/domains-hosts/bing_domain_web
# info recon/domains-hosts/bing_domain_web
# options set SOURCE domain
# run

recon-ng
chmod +x recon.sh
./recon.sh ptit.edu.vn ptit
