# whois, nslookup, dig, whatweb, theharvester, sublist3r, p0f, nmap, reconng, 

# scanvul: nmap script, metasploit, snmp

# sqlmap